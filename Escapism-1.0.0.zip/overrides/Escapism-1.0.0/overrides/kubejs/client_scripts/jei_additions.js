onEvent("jei.add.items", (e) => {
  e.add([
    "tconstruct:crafting_station",
    "tconstruct:tinker_station",
    "tconstruct:part_builder",
    "tconstruct:tinkers_anvil",
    "tconstruct:scorched_anvil",
    "tconstruct:brass_block",
    "tconstruct:molten_brass",
  ]);
});
