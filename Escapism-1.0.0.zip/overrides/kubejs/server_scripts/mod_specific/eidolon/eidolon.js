onEvent("recipes", (e) => {
  removeRecipeByID(e, ["eidolon:lead_block"]);
});
