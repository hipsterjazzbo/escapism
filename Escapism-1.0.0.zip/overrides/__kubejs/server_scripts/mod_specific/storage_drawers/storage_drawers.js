onEvent("recipes", (e) => {
  e.replaceInput(
    {
      output: "storagedrawers:compacting_drawers_3",
      type: "minecraft:crafting_shaped",
    },
    "minecraft:stone",
    "#forge:stone"
  );
  e.replaceInput(
    { output: "storagedrawers:controller", type: "minecraft:crafting_shaped" },
    "minecraft:stone",
    "#forge:stone"
  );
  e.replaceInput(
    {
      output: "storagedrawers:controller_slave",
      type: "minecraft:crafting_shaped",
    },
    "minecraft:stone",
    "#forge:stone"
  );
});
